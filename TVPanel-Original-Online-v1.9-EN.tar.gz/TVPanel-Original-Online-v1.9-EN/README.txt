TVPanel Original Online 1.9 EN
 developed by pp4mnk
==========================

INSTALL / UPDATE (EasyOS, root)
1. Extract this archive.
2. Open a terminal inside TVPanel-Original-Online-v1.9-EN.
3. Run: sh install.sh
4. Close the previous panel and open TVPanel from Multimedia, your
   original shortcut, or run: tvpanel-online
The window title must show TVPanel 1.9 EN M3U.

PACKAGE
install.sh                 Installer updated for version 1.9.
tvpanel-m3u-v1.9-EN.py         Version 1.9 supplied with this package.
defaults.json              Initial channels for a new installation.
README.txt                 Installation, usage and credits.

The installer installs tvpanel-m3u-v1.9-EN.py as:
/usr/local/lib/tvpanel-online/tvpanel-online.py
The launcher /usr/local/bin/tvpanel-online opens that installed file.
Existing noob128_front_end launchers under /root/noob are updated.
The first original launcher backup (.before-online) is preserved.
An existing installed Python program is backed up before replacement.
Your saved channel list and downloaded logos are retained. You do not
need to import your playlists again. defaults.json is only used when
there is no personal channels.json file.

REQUIREMENTS
python3, yad, mpv, and gtkdialog3 or gtkdialog.
The installer checks these dependencies; it does not download them.
YouTube playback may also require a compatible yt-dlp installation.

USE
- IMPORT M3U: import a local M3U/M3U8 channel list or an HTTP(S) URL.
  Choose File or URL, then select channels or use Add all.
- Each channel shows its name below the button, even without a logo.
- Available PNG/JPEG logos are recovered for the visible page and saved
  in the configuration folder. Missing or unsupported logos use a TV icon.
  Recovering missing logos can delay opening a page briefly.
- + opens the IPTV-org catalogue; search by channel name and/or country.
- Click a channel to play it with mpv.
- Previous/Next change pages; minus removes a selected channel.
- Direct import command: tvpanel-online --import-m3u

DATA
~/.config/tvpanel-original/channels.json       Saved channels
~/.config/tvpanel-original/channels.json.bak   Previous channel list
~/.config/tvpanel-original/logos/              Downloaded PNG/JPEG logos
~/.config/tvpanel-original/mpv.log             Latest playback log
~/.cache/tvpanel-original/                    Catalogue and generated icons
Screenshots are saved under /files/media/images/TV_panel_screenshots

On EasyOS sessions without automatic persistence, save your session to
retain the installation, channels and logos after reboot.

CATALOGUE
https://github.com/iptv-org/api
https://iptv-org.github.io/api/
Channel availability depends on the source. The programme does not
bypass geographical restrictions, DRM or subscriptions.

CREDITS
TVPanel Original Online 1.9 EN: developed by pp4mnk
Based on the original TVPanel interface, with historical contributions
credited to Lobster, ETP and Barry Kauler.
Online catalogue: IPTV-org. Channel logos belong to their owners.

VALIDATION
Installer shell syntax, packaged Python syntax, default channel data,
launcher generation and preservation of existing user data checked.
GUI installation and playback have not been tested here on EasyOS.

The EN edition updates the installed TVPanel and shares its saved channels
and logos. YAD system controls follow your desktop language.
