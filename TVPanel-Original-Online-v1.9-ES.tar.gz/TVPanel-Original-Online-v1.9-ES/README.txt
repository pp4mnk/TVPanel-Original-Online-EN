TVPanel Original Online 1.9 ES
developed by pp4mnk
=============================

INSTALACIÓN / ACTUALIZACIÓN (EasyOS, root)
1. Descomprime el paquete.
2. Abre una terminal dentro de TVPanel-Original-Online-v1.9-ES.
3. Ejecuta: sh install.sh
4. Cierra el panel anterior y abre TVPanel ES en Multimedia o ejecuta:
   tvpanel-online
El título debe mostrar TVPanel 1.9 ES M3U.

CONTENIDO
install.sh                 Instalador de la edición ES.
tvpanel-m3u-v1.9-ES.py      Programa con los textos de interfaz traducidos.
defaults.json              Canales iniciales.
README.txt                 Instrucciones y créditos.

El instalador copia esta edición a:
/usr/local/lib/tvpanel-online/tvpanel-online.py
Actualiza el comando /usr/local/bin/tvpanel-online y los lanzadores
noob128_front_end de /root/noob. Conserva la primera copia del lanzador
original (.before-online) y guarda una copia del programa sustituido.
La edición ES sustituye la edición instalada y comparte sus datos;
conserva los canales y logotipos guardados. No hace falta importar de nuevo.

REQUISITOS
python3, yad, mpv y gtkdialog3 o gtkdialog.
Se comprueban las dependencias, pero no se descargan automáticamente.
YouTube puede requerir una instalación compatible de yt-dlp.
Los controles propios de YAD dependen del idioma del sistema. Los nombres
de canales, países y otros datos del catálogo conservan el idioma de origen.

USO
- IMPORTAR M3U: abre un archivo local M3U/M3U8 o una URL HTTP(S).
  Marca los canales que quieras o pulsa Añadir todos.
- +: busca canales en el catálogo de IPTV-org por nombre y/o país.
- Pulsa un canal para reproducirlo con mpv.
- El nombre aparece siempre debajo de su botón.
- Los logotipos PNG/JPEG disponibles se recuperan para la página visible
  y se guardan. Si no hay logotipo, aparece el icono genérico de televisión.
- Las flechas cambian de página; el botón menos permite eliminar canales.
- Importación directa: tvpanel-online --import-m3u

DATOS
~/.config/tvpanel-original/channels.json       Canales guardados
~/.config/tvpanel-original/channels.json.bak   Lista anterior
~/.config/tvpanel-original/logos/              Logotipos descargados
~/.config/tvpanel-original/mpv.log             Registro de reproducción
~/.cache/tvpanel-original/                    Catálogo e iconos generados
Capturas de mpv: /files/media/images/TV_panel_screenshots

Si EasyOS no guarda la sesión automáticamente, guarda la sesión para
conservar instalación, canales y logotipos tras reiniciar.
La disponibilidad de cada emisión depende de su proveedor.

CRÉDITOS
TVPanel Original Online 1.9 ES: developed by pp4mnk
Basado en la interfaz original TVPanel, con contribuciones históricas
atribuidas a Lobster, ETP y Barry Kauler.
Catálogo: IPTV-org (https://github.com/iptv-org/api).
Los logotipos pertenecen a sus respectivos propietarios.

COMPROBACIONES
Sintaxis del programa y del instalador, datos iniciales y estructura
del paquete comprobados. Interfaz gráfica pendiente de probar en EasyOS.
